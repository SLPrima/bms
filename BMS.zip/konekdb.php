<?php
	DEFINE ('DBPEMAKAI', 'dtrenzc1_krt');
	DEFINE ('DBPASSWORD', 'krist109910');
	DEFINE ('DBHOST', 'localhost');
	DEFINE ('DBNAMA', 'dtrenzc1_BLI');
	
	$koneksi = mysqli_connect(DBHOST, DBPEMAKAI, DBPASSWORD, DBNAMA);
	
	if (mysqli_connect_error())
	{
		die("koneksi gagal : ". mysqli_connect_error());
	}
	
?>
		