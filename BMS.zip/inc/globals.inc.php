<?php
define("APP_TITLE", "Welcome to Building Maintenance System");
define("MYSQL_SERVER", "localhost");
define("MYSQL_DB", "dtrenzc1_BLI");
define("MYSQL_USER", "dtrenzc1_krt");
define("MYSQL_PASSWORD", "krist109910");
define("LIST_PAGE_SIZE", 15);
define("DATE_FORMAT", "d-m-Y H:i:s");
define("DATE_FORMAT_ID", "d-m-Y");
define("DATE_FORMAT_JS", "dd-MM-yyyy");
define("DATE_FORMAT_MYSQL", "%d-%m-%Y");
define("DATETIME_FORMAT", "d-m-Y H:i:s");
define("ROOT_URL", "http://localhost/bli/");
define("MAX_ITEM_ROW", 15);
?>