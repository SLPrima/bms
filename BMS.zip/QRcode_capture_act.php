<?php 

//include screenShot class 
include('screenshot.class.php'); 

//use own website url 

$screenShot = new screenShot('http://www.example.com'); 

//display html image tag for captured webpage 

$screenShot->displayImage(); 


//$screenShot->capturePage(); 

//$screenShot->downloadCapture('test.png'); 

//$screenShot->displayCapture(); 


 
//include screenShot class 
include('screenshot.class.php'); 
 
//use own website url 
 
$screenShot = new screenShot('http://www.example.com'); 
 
//display html image tag for captured webpage 
 
$screenShot->displayImage(); 
 
 
//$screenShot->capturePage(); 
 
//$screenShot->downloadCapture('test.png'); 
 
//$screenShot->displayCapture(); 
 
?>