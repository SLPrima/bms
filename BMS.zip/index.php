<?php
header("Location: loginapps.php?compid=9918f747-75ce-11e2-81e9-00235adce306");
?>